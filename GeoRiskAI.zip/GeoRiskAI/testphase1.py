from src.model_features import build_model_dataset
from src.pipeline import build_master_dataset
from src.clustering import CLUSTER_FEATURES

df = build_master_dataset()
data = build_model_dataset(df)

print("Columns in data:", list(data.columns))
print("Shape:", data.shape)

available = [f for f in CLUSTER_FEATURES if f in data.columns]
print("Available cluster features:", available)

agg = data.groupby("Country")[available].mean()
print("Agg shape before fillna:", agg.shape)
print("NaN counts:\n", agg.isna().sum())

agg = agg.fillna(agg.mean())
agg = agg.dropna(axis=1)
print("Agg shape after fillna:", agg.shape)
from src.model_features import build_model_dataset
from src.pipeline import build_master_dataset
from src.clustering import CLUSTER_FEATURES

df = build_master_dataset()
data = build_model_dataset(df)

print("Columns in data:", list(data.columns))
print("Shape:", data.shape)

available = [f for f in CLUSTER_FEATURES if f in data.columns]
print("Available cluster features:", available)

agg = data.groupby("Country")[available].mean()
print("Agg shape before fillna:", agg.shape)
print("NaN counts:\n", agg.isna().sum())

agg = agg.fillna(agg.mean())
agg = agg.dropna(axis=1)
print("Agg shape after fillna:", agg.shape)