import sys
import os

sys.path.append(os.path.abspath("."))

import streamlit as st
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from src.pipeline import build_master_dataset
from src.analysis import conflicts_by_year
from src.risk_engine import country_risk_score
from src.risk_map import plot_risk_map
from src.model_features import train_model, predict_next_year
from src.clustering import run_clustering, cluster_summary, CLUSTER_COLORS
from src.escalation import train_escalation_model, predict_escalation, ESCALATION_COLORS
from src.news_fetcher import get_live_news, fetch_conflict_signals, compute_news_risk_score
from src.anomaly_detector import (
    fetch_all_news_scores,
    compute_live_score,
    detect_anomalies,
    get_alert_level,
)


# ─────────────────────────────────────────────
# PAGE CONFIG
# ─────────────────────────────────────────────

st.set_page_config(
    page_title="GeoRiskAI",
    page_icon="🌍",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ─────────────────────────────────────────────
# CUSTOM CSS
# ─────────────────────────────────────────────

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Share+Tech+Mono&family=Exo+2:wght@300;400;600&display=swap');

/* Global */
html, body, [class*="css"] {
    font-family: 'Exo 2', sans-serif;
    background-color: #080c14;
    color: #c8d6e5;
}

/* Main background */
.stApp {
    background: linear-gradient(135deg, #080c14 0%, #0d1520 50%, #080c14 100%);
}

/* Animated grid background */
.stApp::before {
    content: '';
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background-image:
        linear-gradient(rgba(0,200,255,0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(0,200,255,0.03) 1px, transparent 1px);
    background-size: 50px 50px;
    pointer-events: none;
    z-index: 0;
}

/* Title */
h1 {
    font-family: 'Rajdhani', sans-serif !important;
    font-size: 2.8rem !important;
    font-weight: 700 !important;
    letter-spacing: 4px !important;
    text-transform: uppercase !important;
    background: linear-gradient(90deg, #00c8ff, #0066ff, #00c8ff);
    background-size: 200% auto;
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: shine 3s linear infinite;
}

@keyframes shine {
    to { background-position: 200% center; }
}

/* Subheaders */
h2, h3 {
    font-family: 'Rajdhani', sans-serif !important;
    letter-spacing: 2px !important;
    text-transform: uppercase !important;
    color: #00c8ff !important;
    border-bottom: 1px solid rgba(0,200,255,0.2) !important;
    padding-bottom: 6px !important;
}

/* Metric cards */
[data-testid="metric-container"] {
    background: linear-gradient(135deg, rgba(0,200,255,0.05), rgba(0,100,255,0.08));
    border: 1px solid rgba(0,200,255,0.2);
    border-radius: 8px;
    padding: 16px !important;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

[data-testid="metric-container"]:hover {
    border-color: rgba(0,200,255,0.5);
    box-shadow: 0 0 20px rgba(0,200,255,0.1);
    transform: translateY(-2px);
}

[data-testid="metric-container"]::before {
    content: '';
    position: absolute;
    top: 0; left: 0;
    width: 3px; height: 100%;
    background: linear-gradient(180deg, #00c8ff, #0066ff);
}

[data-testid="stMetricValue"] {
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 2rem !important;
    color: #00c8ff !important;
}

[data-testid="stMetricLabel"] {
    font-family: 'Rajdhani', sans-serif !important;
    letter-spacing: 1px !important;
    text-transform: uppercase !important;
    color: #7a9bb5 !important;
    font-size: 0.75rem !important;
}

/* Tabs */
.stTabs [data-baseweb="tab-list"] {
    background: rgba(0,200,255,0.03);
    border-bottom: 1px solid rgba(0,200,255,0.15);
    gap: 0;
}

.stTabs [data-baseweb="tab"] {
    font-family: 'Rajdhani', sans-serif !important;
    font-weight: 600 !important;
    letter-spacing: 1.5px !important;
    text-transform: uppercase !important;
    font-size: 0.8rem !important;
    color: #4a7a9b !important;
    border-bottom: 2px solid transparent !important;
    padding: 12px 20px !important;
    transition: all 0.2s !important;
}

.stTabs [aria-selected="true"] {
    color: #00c8ff !important;
    border-bottom: 2px solid #00c8ff !important;
    background: rgba(0,200,255,0.05) !important;
}

/* Sidebar */
[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0a1628 0%, #080c14 100%) !important;
    border-right: 1px solid rgba(0,200,255,0.1) !important;
}

[data-testid="stSidebar"] h1,
[data-testid="stSidebar"] h2,
[data-testid="stSidebar"] h3 {
    color: #00c8ff !important;
}

/* Buttons */
.stButton button {
    background: linear-gradient(135deg, rgba(0,200,255,0.1), rgba(0,100,255,0.15)) !important;
    border: 1px solid rgba(0,200,255,0.3) !important;
    color: #00c8ff !important;
    font-family: 'Rajdhani', sans-serif !important;
    font-weight: 600 !important;
    letter-spacing: 2px !important;
    text-transform: uppercase !important;
    border-radius: 4px !important;
    transition: all 0.3s ease !important;
}

.stButton button:hover {
    background: linear-gradient(135deg, rgba(0,200,255,0.2), rgba(0,100,255,0.25)) !important;
    border-color: #00c8ff !important;
    box-shadow: 0 0 15px rgba(0,200,255,0.2) !important;
    transform: translateY(-1px) !important;
}

/* Dataframes */
[data-testid="stDataFrame"] {
    border: 1px solid rgba(0,200,255,0.15) !important;
    border-radius: 8px !important;
}

/* Selectbox */
[data-baseweb="select"] {
    background: rgba(0,200,255,0.05) !important;
    border: 1px solid rgba(0,200,255,0.2) !important;
}

/* Divider */
hr {
    border-color: rgba(0,200,255,0.1) !important;
}

/* Caption */
.stCaption {
    color: #4a7a9b !important;
    font-family: 'Share Tech Mono', monospace !important;
    font-size: 0.75rem !important;
}

/* Alerts */
.stAlert {
    border-radius: 6px !important;
    border-left: 3px solid !important;
    font-family: 'Share Tech Mono', monospace !important;
}

/* Spinner */
.stSpinner {
    color: #00c8ff !important;
}

/* Scrollbar */
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: #080c14; }
::-webkit-scrollbar-thumb { background: rgba(0,200,255,0.3); border-radius: 2px; }

/* Pulse animation for alerts */
@keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.6; }
}

.threat-alert {
    animation: pulse 2s infinite;
}
</style>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# HEADER
# ─────────────────────────────────────────────

st.markdown("""
<div style='text-align:center; padding: 20px 0 10px 0;'>
    <h1 style='font-family: Rajdhani, sans-serif; font-size: 3rem;
               letter-spacing: 8px; text-transform: uppercase;
               background: linear-gradient(90deg, #00c8ff, #0066ff, #00c8ff);
               background-size: 200% auto;
               -webkit-background-clip: text;
               -webkit-text-fill-color: transparent;'>
        🌍 GeoRisk Intelligence
    </h1>
    <p style='font-family: Share Tech Mono, monospace; color: #4a7a9b;
              letter-spacing: 4px; font-size: 0.75rem; margin-top: -10px;'>
        GEOPOLITICAL CONFLICT PREDICTION SYSTEM — POWERED BY MACHINE LEARNING
    </p>
</div>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# MATPLOTLIB DARK THEME
# ─────────────────────────────────────────────

plt.rcParams.update({
    "figure.facecolor":  "#0d1520",
    "axes.facecolor":    "#0d1520",
    "axes.edgecolor":    "#1a3a5c",
    "axes.labelcolor":   "#7a9bb5",
    "axes.titlecolor":   "#00c8ff",
    "xtick.color":       "#4a7a9b",
    "ytick.color":       "#4a7a9b",
    "text.color":        "#c8d6e5",
    "grid.color":        "#1a2a3a",
    "grid.alpha":        0.4,
    "font.family":       "monospace",
    "axes.spines.top":   False,
    "axes.spines.right": False,
})


# ─────────────────────────────────────────────
# DATA & MODEL
# ─────────────────────────────────────────────

@st.cache_data
def load_data(live=False):
    return build_master_dataset(use_live_data=live)


@st.cache_resource
def load_model(_df):
    model, report, _, _ = train_model(_df)
    return model, report


@st.cache_resource
def load_escalation_model(_df):
    model, report = train_escalation_model(_df)
    return model, report


# ─────────────────────────────────────────────
# SIDEBAR
# ─────────────────────────────────────────────

st.sidebar.markdown("""
<div style='text-align:center; padding: 10px 0;'>
    <p style='font-family: Rajdhani, sans-serif; font-size: 1.2rem;
              letter-spacing: 3px; color: #00c8ff; text-transform: uppercase;'>
        ⚙ Control Panel
    </p>
</div>
""", unsafe_allow_html=True)

st.sidebar.markdown("**FILTERS**")
all_countries_placeholder = st.sidebar.empty()
year_min_placeholder = st.sidebar.empty()

st.sidebar.divider()
st.sidebar.markdown("**DATA SOURCE**")

use_live = st.sidebar.toggle(
    "Use live World Bank data",
    value=False,
)

if st.sidebar.button("↻ Refresh World Bank Data"):
    from src.world_bank_fetcher import fetch_world_bank_data, save_world_bank_data
    with st.spinner("Fetching live data from World Bank API..."):
        wb_df = fetch_world_bank_data()
        save_world_bank_data(wb_df)
    st.sidebar.success("✓ Data refreshed!")
    st.cache_data.clear()
    st.rerun()

df = load_data(live=use_live)
model, report = load_model(df)
escalation_model, escalation_report = load_escalation_model(df)

all_countries = sorted(df["Country"].unique())
selected_countries = all_countries_placeholder.multiselect(
    "Focus on countries",
    options=all_countries,
    default=[],
    placeholder="All countries",
)

year_min, year_max = int(df["Year"].min()), int(df["Year"].max())
year_range = year_min_placeholder.slider(
    "Year range",
    min_value=year_min,
    max_value=year_max,
    value=(year_min, year_max),
)

filtered_df = df[
    (df["Year"] >= year_range[0]) &
    (df["Year"] <= year_range[1])
]
if selected_countries:
    filtered_df = filtered_df[
        filtered_df["Country"].isin(selected_countries)
    ]

# Sidebar stats
st.sidebar.divider()
st.sidebar.markdown("**SYSTEM STATUS**")
predictions_all = predict_next_year(model, df)
critical_count = (predictions_all["Risk_Level"] == "Critical").sum()
st.sidebar.markdown(f"""
<div style='font-family: Share Tech Mono, monospace; font-size: 0.75rem;
            color: #4a7a9b; line-height: 2;'>
    <span style='color:#e24b4a'>●</span> Critical threats: {critical_count}<br>
    <span style='color:#ef9f27'>●</span> Countries monitored: {df['Country'].nunique()}<br>
    <span style='color:#00c8ff'>●</span> Data range: {year_min}–{year_max}<br>
    <span style='color:#1d9e75'>●</span> Model accuracy: {report['accuracy']:.1%}
</div>
""", unsafe_allow_html=True)


# ─────────────────────────────────────────────
# TABS
# ─────────────────────────────────────────────

tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8 = st.tabs([
    "🔮 Predictions",
    "📊 Model Evaluation",
    "⚠️ Risk Rankings",
    "📈 Conflict Trends",
    "🗺️ Risk Clusters",
    "🔥 Escalation",
    "📰 Live News",
    "🚨 Emerging Threats",
])


# ── TAB 1: PREDICTIONS ──────────────────────

with tab1:
    st.subheader("Next-Year Conflict Probability")
    st.caption("► PREDICTED PROBABILITY OF CONFLICT IN YEAR T+1")

    predictions = predict_next_year(model, df)
    if selected_countries:
        predictions = predictions[
            predictions["Country"].isin(selected_countries)
        ]

    risk_colors = {
        "Critical": "#e24b4a",
        "High":     "#ef9f27",
        "Moderate": "#378add",
        "Low":      "#1d9e75",
    }

    col1, col2, col3, col4 = st.columns(4)
    for col, level in zip(
        [col1, col2, col3, col4],
        ["Critical", "High", "Moderate", "Low"]
    ):
        count = (predictions["Risk_Level"] == level).sum()
        col.metric(label=f"{level} Risk", value=count)

    st.divider()

    top20 = predictions.head(20)
    colors = [risk_colors[r] for r in top20["Risk_Level"]]

    fig, ax = plt.subplots(figsize=(11, 7))
    bars = ax.barh(
        top20["Country"], top20["Conflict_Probability"],
        color=colors, alpha=0.85, height=0.65,
    )
    # Add value labels
    for bar, val in zip(bars, top20["Conflict_Probability"]):
        ax.text(
            min(val + 0.01, 0.98), bar.get_y() + bar.get_height() / 2,
            f"{val:.1%}", va="center", ha="left",
            fontsize=8, color="#c8d6e5",
        )
    ax.set_xlabel("Conflict Probability", labelpad=10)
    ax.set_title("TOP 20 — PREDICTED CONFLICT RISK", pad=15, fontsize=11)
    ax.invert_yaxis()
    ax.axvline(0.5, color="#4a7a9b", linestyle="--", linewidth=0.8, alpha=0.7)
    ax.set_xlim(0, 1.05)
    ax.grid(axis="x", alpha=0.2)
    fig.tight_layout()
    st.pyplot(fig)

    st.divider()
    st.subheader("All Countries")

    # Plotly interactive table
    fig_table = go.Figure(data=[go.Table(
        header=dict(
            values=["Country", "Conflict Probability", "Risk Level"],
            fill_color="#0d1f35",
            font=dict(color="#00c8ff", size=12, family="Share Tech Mono"),
            align="left",
            height=35,
        ),
        cells=dict(
            values=[
                predictions["Country"],
                predictions["Conflict_Probability"].apply(lambda x: f"{x:.1%}"),
                predictions["Risk_Level"],
            ],
            fill_color=[
                ["#0a1628"] * len(predictions),
                ["#0a1628"] * len(predictions),
                [
                    "#3d0f0f" if r == "Critical" else
                    "#3d2a0f" if r == "High" else
                    "#0f2a3d" if r == "Moderate" else
                    "#0f3d1f"
                    for r in predictions["Risk_Level"]
                ],
            ],
            font=dict(color="#c8d6e5", size=11, family="Share Tech Mono"),
            align="left",
            height=28,
        ),
    )])
    fig_table.update_layout(
        paper_bgcolor="#080c14",
        margin=dict(l=0, r=0, t=0, b=0),
        height=500,
    )
    st.plotly_chart(fig_table, use_container_width=True)


# ── TAB 2: MODEL EVALUATION ─────────────────

with tab2:
    st.subheader("Model Performance")
    st.caption("► RANDOM FOREST CLASSIFIER — EVALUATION METRICS")

    col1, col2, col3 = st.columns(3)
    col1.metric("Accuracy", f"{report['accuracy']:.2%}")
    col2.metric("ROC-AUC", f"{report['roc_auc']:.4f}")
    col3.metric("Test Samples", "2,739")

    st.divider()

    col_left, col_right = st.columns(2)

    with col_left:
        st.subheader("Confusion Matrix")
        cm = report["confusion_matrix"]
        fig, ax = plt.subplots(figsize=(5, 4))
        im = ax.imshow(cm, cmap="Blues", alpha=0.85)
        ax.set_xticks([0, 1])
        ax.set_yticks([0, 1])
        ax.set_xticklabels(["No Conflict", "Conflict"])
        ax.set_yticklabels(["No Conflict", "Conflict"])
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")
        for i in range(2):
            for j in range(2):
                ax.text(
                    j, i, f"{cm[i][j]:,}",
                    ha="center", va="center", fontsize=14,
                    color="white" if cm[i][j] > cm.max() / 2 else "#c8d6e5",
                )
        plt.colorbar(im, ax=ax)
        fig.tight_layout()
        st.pyplot(fig)

    with col_right:
        st.subheader("Feature Importances")
        fi = pd.Series(report["feature_importances"]).sort_values(ascending=True)
        fig, ax = plt.subplots(figsize=(5, 4))
        colors_fi = ["#00c8ff" if i == len(fi) - 1 else "#1a6a9a" for i in range(len(fi))]
        fi.plot(kind="barh", ax=ax, color=colors_fi, alpha=0.85)
        ax.set_xlabel("Importance")
        ax.set_title("FEATURE IMPORTANCES")
        for i, (val, name) in enumerate(zip(fi.values, fi.index)):
            ax.text(val + 0.002, i, f"{val:.3f}", va="center", fontsize=8)
        ax.grid(axis="x", alpha=0.2)
        fig.tight_layout()
        st.pyplot(fig)

    st.divider()
    st.subheader("Classification Report")
    cr = report["classification_report"]
    cr_df = pd.DataFrame(cr).transpose().round(3)
    st.dataframe(cr_df, use_container_width=True)


# ── TAB 3: RISK RANKINGS ────────────────────

with tab3:
    st.subheader("Historical Instability Rankings")
    st.caption("► CONFLICT FREQUENCY RATIO — ALL AVAILABLE YEARS")

    risk_scores = country_risk_score(filtered_df)

    col1, col2 = st.columns([2, 1])

    with col1:
        fig, ax = plt.subplots(figsize=(9, 6))
        top15 = risk_scores.head(15)
        colors_r = [
            "#e24b4a" if v > 0.6 else
            "#ef9f27" if v > 0.3 else
            "#378add"
            for v in top15.values
        ]
        bars = ax.bar(
            range(len(top15)), top15.values,
            color=colors_r, alpha=0.85, width=0.65,
        )
        ax.set_xticks(range(len(top15)))
        ax.set_xticklabels(top15.index, rotation=40, ha="right", fontsize=9)
        ax.set_ylabel("Instability Score")
        ax.set_title("TOP 15 — MOST CONFLICT-PRONE COUNTRIES")
        for bar, val in zip(bars, top15.values):
            ax.text(
                bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.005,
                f"{val:.2f}", ha="center", fontsize=8,
            )
        ax.grid(axis="y", alpha=0.2)
        fig.tight_layout()
        st.pyplot(fig)

    with col2:
        st.markdown("<br>", unsafe_allow_html=True)
        ranked = risk_scores.reset_index()
        ranked.columns = ["Country", "Score"]
        ranked["Score"] = ranked["Score"].round(3)
        ranked.index = ranked.index + 1
        st.dataframe(ranked.head(20), use_container_width=True)

    st.divider()
    st.subheader("Global Risk Map")
    plot_risk_map(risk_scores)


# ── TAB 4: CONFLICT TRENDS ──────────────────

with tab4:
    st.subheader("Global Conflict Trend")
    st.caption(f"► {year_range[0]} — {year_range[1]}")

    conflict_year = conflicts_by_year(filtered_df)

    fig, ax = plt.subplots(figsize=(11, 4))
    ax.fill_between(
        conflict_year.index, conflict_year.values,
        alpha=0.15, color="#00c8ff",
    )
    ax.plot(
        conflict_year.index, conflict_year.values,
        color="#00c8ff", linewidth=2, zorder=5,
    )
    # Highlight peak
    peak_year = conflict_year.idxmax()
    peak_val = conflict_year.max()
    ax.scatter([peak_year], [peak_val], color="#e24b4a", s=80, zorder=6)
    ax.annotate(
        f"Peak: {peak_year}",
        (peak_year, peak_val),
        textcoords="offset points", xytext=(10, 5),
        color="#e24b4a", fontsize=8,
    )
    ax.set_xlabel("Year")
    ax.set_ylabel("Number of Conflicts")
    ax.set_title("GLOBAL CONFLICTS OVER TIME")
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    st.pyplot(fig)

    if selected_countries:
        st.divider()
        st.subheader("Country-Level Conflict Timeline")
        country_data = filtered_df[filtered_df["Conflict"] == 1]
        fig_px = px.line(
            country_data.groupby(
                ["Year", "Country"]
            ).size().reset_index(name="Conflicts"),
            x="Year", y="Conflicts", color="Country",
            title="CONFLICT EVENTS BY COUNTRY",
            template="plotly_dark",
            color_discrete_sequence=px.colors.qualitative.Set1,
        )
        fig_px.update_layout(
            paper_bgcolor="#080c14",
            plot_bgcolor="#0d1520",
            font=dict(family="Share Tech Mono", color="#c8d6e5"),
            title_font=dict(color="#00c8ff"),
        )
        st.plotly_chart(fig_px, use_container_width=True)


# ── TAB 5: RISK CLUSTERS ────────────────────

with tab5:
    st.subheader("Regional Risk Clustering")
    st.caption("► K-MEANS CLUSTERING — 4 GEOPOLITICAL RISK PROFILES")

    result_df, kmeans, scaler, pca_df = run_clustering(df)

    col1, col2, col3, col4 = st.columns(4)
    cluster_icons = {
        "Stable": "✅",
        "Fragile": "⚡",
        "Conflict-Prone": "⚠️",
        "Chronically Unstable": "🔴",
    }
    for col, label in zip(
        [col1, col2, col3, col4],
        ["Stable", "Fragile", "Conflict-Prone", "Chronically Unstable"]
    ):
        count = (result_df["Cluster_Label"] == label).sum()
        col.metric(
            label=f"{cluster_icons[label]} {label}",
            value=f"{count}",
        )

    st.divider()
    st.subheader("Cluster Map")
    st.caption("► PCA PROJECTION — EACH DOT IS A COUNTRY")

    # Plotly scatter for interactivity
    fig_scatter = px.scatter(
        pca_df,
        x="PCA_1", y="PCA_2",
        color="Cluster_Label",
        hover_name="Country",
        hover_data={"Instability": ":.3f"},
        color_discrete_map=CLUSTER_COLORS,
        title="COUNTRY RISK CLUSTERS — PCA PROJECTION",
        template="plotly_dark",
    )
    fig_scatter.update_traces(marker=dict(size=8, opacity=0.85, line=dict(width=0.5, color="#080c14")))
    fig_scatter.update_layout(
        paper_bgcolor="#080c14",
        plot_bgcolor="#0d1520",
        font=dict(family="Share Tech Mono", color="#c8d6e5"),
        title_font=dict(color="#00c8ff"),
        legend_title_text="Cluster",
    )
    st.plotly_chart(fig_scatter, use_container_width=True)

    st.divider()
    st.subheader("Cluster Profiles")
    summary = cluster_summary(result_df)
    st.dataframe(
        summary.style.background_gradient(cmap="RdYlGn_r"),
        use_container_width=True,
    )

    st.divider()
    st.subheader("Countries by Cluster")
    selected_cluster = st.selectbox(
        "Select a cluster",
        options=["Stable", "Fragile", "Conflict-Prone", "Chronically Unstable"],
    )
    cluster_countries = result_df[
        result_df["Cluster_Label"] == selected_cluster
    ][
        ["Country", "Instability_Score", "Conflict_Rate_5yr", "Conflict_Rate_3yr"]
    ].sort_values("Instability_Score", ascending=False)
    st.dataframe(
        cluster_countries.reset_index(drop=True),
        use_container_width=True,
    )


# ── TAB 6: ESCALATION ───────────────────────

with tab6:
    st.subheader("Conflict Escalation Prediction")
    st.caption("► MULTI-CLASS — NO CONFLICT / MINOR / MAJOR")

    escalation_preds = predict_escalation(escalation_model, df)
    if selected_countries:
        escalation_preds = escalation_preds[
            escalation_preds["Country"].isin(selected_countries)
        ]

    col1, col2, col3 = st.columns(3)
    esc_icons = {"No Conflict": "✅", "Minor": "⚠️", "Major": "🔴"}
    for col, level in zip([col1, col2, col3], ["No Conflict", "Minor", "Major"]):
        count = (escalation_preds["Predicted_Level"] == level).sum()
        col.metric(label=f"{esc_icons[level]} {level}", value=count)

    st.divider()
    st.subheader("Top 20 — Escalation Breakdown")

    top20_esc = escalation_preds.head(20)

    fig, ax = plt.subplots(figsize=(11, 7))
    ax.barh(
        top20_esc["Country"], top20_esc["No_Conflict_Prob"],
        color="#1d9e75", label="No Conflict", alpha=0.85,
    )
    ax.barh(
        top20_esc["Country"], top20_esc["Minor_Prob"],
        left=top20_esc["No_Conflict_Prob"],
        color="#ef9f27", label="Minor", alpha=0.85,
    )
    ax.barh(
        top20_esc["Country"], top20_esc["Major_Prob"],
        left=top20_esc["No_Conflict_Prob"] + top20_esc["Minor_Prob"],
        color="#e24b4a", label="Major", alpha=0.85,
    )
    ax.set_xlabel("Probability")
    ax.set_title("ESCALATION PROBABILITY BREAKDOWN")
    ax.invert_yaxis()
    ax.legend(loc="lower right")
    ax.set_xlim(0, 1)
    ax.grid(axis="x", alpha=0.2)
    fig.tight_layout()
    st.pyplot(fig)

    st.divider()
    col_l, col_r = st.columns(2)

    with col_l:
        st.subheader("Model Performance")
        col_a, col_b = st.columns(2)
        col_a.metric("Accuracy", f"{escalation_report['accuracy']:.2%}")
        er_df = pd.DataFrame(
            escalation_report["classification_report"]
        ).transpose().round(3)
        st.dataframe(er_df, use_container_width=True)

    with col_r:
        st.subheader("Confusion Matrix")
        ecm = escalation_report["confusion_matrix"]
        fig, ax = plt.subplots(figsize=(5, 4))
        im = ax.imshow(ecm, cmap="Reds", alpha=0.85)
        labels = ["No Conflict", "Minor", "Major"]
        ax.set_xticks([0, 1, 2])
        ax.set_yticks([0, 1, 2])
        ax.set_xticklabels(labels, rotation=15)
        ax.set_yticklabels(labels)
        ax.set_xlabel("Predicted")
        ax.set_ylabel("Actual")
        for i in range(3):
            for j in range(3):
                ax.text(
                    j, i, ecm[i][j],
                    ha="center", va="center", fontsize=12,
                    color="white" if ecm[i][j] > ecm.max() / 2 else "#c8d6e5",
                )
        plt.colorbar(im, ax=ax)
        fig.tight_layout()
        st.pyplot(fig)

    st.divider()
    st.subheader("All Countries — Escalation Forecast")
    st.dataframe(
        escalation_preds.style.background_gradient(
            subset=["Major_Prob"], cmap="Reds",
        ),
        use_container_width=True,
    )


# ── TAB 7: LIVE NEWS ────────────────────────

with tab7:
    st.subheader("Live Conflict News Intelligence")
    st.caption("► REAL-TIME FEED — CONFLICT-FILTERED ARTICLES ONLY")

    news_country = st.selectbox(
        "Select a country",
        options=all_countries,
        index=list(all_countries).index("Iraq")
        if "Iraq" in all_countries else 0,
        key="news_country",
    )

    if st.button("⚡ Fetch Latest News"):
        with st.spinner(f"Scanning news feed for {news_country}..."):
            articles = get_live_news(news_country, max_records=8)

        if articles:
            for article in articles:
                st.markdown(f"""
<div style='background: rgba(0,200,255,0.04); border: 1px solid rgba(0,200,255,0.15);
            border-left: 3px solid #00c8ff; border-radius: 6px;
            padding: 14px 18px; margin-bottom: 12px;'>
    <p style='font-family: Exo 2, sans-serif; font-size: 0.95rem;
              color: #c8d6e5; margin: 0 0 6px 0; font-weight: 600;'>
        {article['title']}
    </p>
    <p style='font-family: Share Tech Mono, monospace; font-size: 0.72rem;
              color: #4a7a9b; margin: 0;'>
        {article['source']} — {article['date']}
        &nbsp;&nbsp;|&nbsp;&nbsp;
        <a href='{article['url']}' target='_blank'
           style='color: #00c8ff; text-decoration: none;'>
            READ ARTICLE →
        </a>
    </p>
</div>
""", unsafe_allow_html=True)
        else:
            st.warning(
                f"No recent conflict articles found for {news_country}. "
                "Try another country."
            )

    st.divider()
    st.subheader("Live Conflict Signals — Top Risk Countries")
    st.caption("► CONFLICT ARTICLE COUNTS — PAST 7 DAYS")

    top_countries = predictions_all.head(10)["Country"].tolist()

    if st.button("📡 Fetch Live Signals"):
        with st.spinner("Fetching live signals..."):
            signals_df = fetch_conflict_signals(top_countries)
            signals_df = compute_news_risk_score(signals_df)

        fig_sig = px.bar(
            signals_df.sort_values("News_Risk_Score", ascending=True),
            x="News_Risk_Score", y="Country",
            orientation="h",
            title="LIVE NEWS RISK SIGNALS",
            template="plotly_dark",
            color="News_Risk_Score",
            color_continuous_scale=["#1d9e75", "#ef9f27", "#e24b4a"],
        )
        fig_sig.update_layout(
            paper_bgcolor="#080c14",
            plot_bgcolor="#0d1520",
            font=dict(family="Share Tech Mono", color="#c8d6e5"),
            title_font=dict(color="#00c8ff"),
            coloraxis_showscale=False,
        )
        st.plotly_chart(fig_sig, use_container_width=True)
        st.dataframe(signals_df, use_container_width=True)


# ── TAB 8: EMERGING THREATS ─────────────────

with tab8:
    st.subheader("Emerging Threat Detector")
    st.caption("► REAL-TIME ANOMALY DETECTION — 50 COUNTRIES SCANNED")

    st.markdown("""
<div style='background: rgba(226,75,74,0.08); border: 1px solid rgba(226,75,74,0.3);
            border-radius: 8px; padding: 14px 18px; margin-bottom: 16px;'>
    <p style='font-family: Share Tech Mono, monospace; font-size: 0.8rem;
              color: #e24b4a; margin: 0;'>
        ⚡ SYSTEM — Flags countries where live news signals exceed historical ML predictions.
        High news score + Low ML probability = Emerging threat not yet captured by the model.
    </p>
</div>
""", unsafe_allow_html=True)

    if st.button("🚨 Run Emerging Threat Scan"):
        with st.spinner("Scanning 50 countries via NewsAPI..."):
            news_df = fetch_all_news_scores()
            live_df = compute_live_score(predictions_all, news_df)
            anomalies = detect_anomalies(
                live_df,
                news_threshold=0.1,
                ml_threshold=0.6,
            )
            live_df["Alert"] = live_df.apply(
                lambda r: get_alert_level(
                    r["News_Risk_Score"],
                    r["Conflict_Probability"],
                ),
                axis=1,
            )

        # Debug
        st.markdown("**News scores fetched:**")
        st.dataframe(news_df, use_container_width=True)

        st.divider()
        st.subheader("Emerging Threats — Not on ML Radar")

        if anomalies.empty:
            st.success(
                "✓ No emerging threats detected. "
                "News signals align with historical model."
            )
        else:
            for _, row in anomalies.iterrows():
                st.markdown(f"""
<div class='threat-alert' style='background: rgba(226,75,74,0.1);
     border: 1px solid rgba(226,75,74,0.4); border-left: 4px solid #e24b4a;
     border-radius: 6px; padding: 12px 16px; margin-bottom: 10px;'>
    <p style='font-family: Rajdhani, sans-serif; font-size: 1.1rem;
              color: #e24b4a; margin: 0 0 4px 0; font-weight: 700;'>
        🚨 {row['Country'].upper()}
    </p>
    <p style='font-family: Share Tech Mono, monospace; font-size: 0.75rem;
              color: #c8d6e5; margin: 0;'>
        News Risk: {row['News_Risk_Score']:.0%} &nbsp;|&nbsp;
        ML Probability: {row['Conflict_Probability']:.0%} &nbsp;|&nbsp;
        Gap: +{row['Anomaly_Gap']:.0%}
    </p>
</div>
""", unsafe_allow_html=True)

        st.divider()
        st.subheader("GeoRisk Live Score — Top 20")
        st.caption("► ML PROBABILITY (60%) + NEWS SIGNAL (40%)")

        top20_live = live_df.head(20)
        fig_live = px.bar(
            top20_live,
            x="GeoRisk_Live_Score", y="Country",
            orientation="h",
            title="TOP 20 — GEORISK LIVE SCORE",
            template="plotly_dark",
            color="GeoRisk_Live_Score",
            color_continuous_scale=["#1d9e75", "#ef9f27", "#e24b4a"],
            hover_data=["Conflict_Probability", "News_Risk_Score"],
        )
        fig_live.update_layout(
            paper_bgcolor="#080c14",
            plot_bgcolor="#0d1520",
            font=dict(family="Share Tech Mono", color="#c8d6e5"),
            title_font=dict(color="#00c8ff"),
            coloraxis_showscale=False,
        )
        fig_live.update_yaxes(autorange="reversed")
        st.plotly_chart(fig_live, use_container_width=True)

        st.divider()
        st.subheader("All Countries — Live Intelligence")
        display_cols = [
            "Country", "Conflict_Probability",
            "News_Risk_Score", "GeoRisk_Live_Score", "Alert",
        ]
        available = [c for c in display_cols if c in live_df.columns]
        st.dataframe(
            live_df[available].style.background_gradient(
                subset=["GeoRisk_Live_Score"], cmap="Reds",
            ),
            use_container_width=True,
    )

    if st.button("🔍 Debug NewsAPI"):
        import requests
        from datetime import datetime, timedelta
        from_date = (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
        params = {
            "q": "Yemen",
            "from": from_date,
            "pageSize": 10,
            "language": "en",
            "apiKey": "4074a62c1508455cb35e8713822999dd",
        }
        response = requests.get("https://newsapi.org/v2/everything", params=params, timeout=15)
        data = response.json()
        st.write("Status:", data.get("status"))
        st.write("Total results:", data.get("totalResults"))
        st.write("Message:", data.get("message", "none"))
        if data.get("articles"):
            for a in data["articles"][:3]:
                st.write(a.get("title"))