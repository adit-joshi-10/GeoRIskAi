import sys
import os

sys.path.append(os.path.abspath("."))

from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
import pandas as pd

from src.pipeline import build_master_dataset
from src.model_features import train_model, predict_next_year
from src.clustering import run_clustering
from src.risk_engine import country_risk_score


# ─────────────────────────────────────────────
# APP INIT
# ─────────────────────────────────────────────

app = FastAPI(
    title="GeoRiskAI API",
    description="Geopolitical conflict prediction API powered by Machine Learning",
    version="1.0.0",
)


# ─────────────────────────────────────────────
# LOAD DATA & MODEL AT STARTUP
# ─────────────────────────────────────────────

print("Loading data...")
df = build_master_dataset()

print("Training model...")
model, report, _, _ = train_model(df)

print("Running clustering...")
result_df, _, _, pca_df = run_clustering(df)

print("Computing risk scores...")
risk_scores = country_risk_score(df)

print("API ready.")


# ─────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────

@app.get("/")
def root():
    return {
        "name": "GeoRiskAI API",
        "version": "1.0.0",
        "endpoints": [
            "/predict/all",
            "/predict/{country}",
            "/clusters",
            "/risk/top",
            "/model/evaluation",
        ]
    }


@app.get("/predict/all")
def predict_all():
    """
    Returns conflict probability predictions for all countries.
    """
    predictions = predict_next_year(model, df)
    return JSONResponse(content=predictions.to_dict(orient="records"))


@app.get("/predict/{country}")
def predict_country(country: str):
    """
    Returns conflict probability prediction for a single country.
    Example: /predict/Iraq
    """
    predictions = predict_next_year(model, df)

    match = predictions[
        predictions["Country"].str.lower() == country.lower()
    ]

    if match.empty:
        raise HTTPException(
            status_code=404,
            detail=f"Country '{country}' not found. Check spelling."
        )

    return JSONResponse(content=match.to_dict(orient="records")[0])


@app.get("/clusters")
def get_clusters():
    """
    Returns cluster assignments for all countries.
    """
    output = result_df[["Country", "Cluster_Label"]].copy()
    output = output.merge(
        pca_df[["Country", "PCA_1", "PCA_2", "Instability"]],
        on="Country",
        how="left",
    )
    return JSONResponse(content=output.to_dict(orient="records"))


@app.get("/clusters/{cluster_label}")
def get_cluster_countries(cluster_label: str):
    """
    Returns all countries in a specific cluster.
    Options: Stable, Fragile, Conflict-Prone, Chronically Unstable
    """
    valid = ["Stable", "Fragile", "Conflict-Prone", "Chronically Unstable"]

    match = result_df[
        result_df["Cluster_Label"].str.lower() == cluster_label.lower()
    ]

    if match.empty:
        raise HTTPException(
            status_code=404,
            detail=f"Cluster '{cluster_label}' not found. Valid options: {valid}"
        )

    output = match[["Country", "Cluster_Label", "Instability_Score"]].copy()
    output = output.sort_values("Instability_Score", ascending=False)
    return JSONResponse(content=output.to_dict(orient="records"))


@app.get("/risk/top")
def top_risk(n: int = 10):
    """
    Returns top N highest risk countries by instability score.
    Example: /risk/top?n=20
    """
    top = risk_scores.head(n).reset_index()
    top.columns = ["Country", "Instability_Score"]
    return JSONResponse(content=top.to_dict(orient="records"))


@app.get("/model/evaluation")
def model_evaluation():
    """
    Returns model performance metrics.
    """
    cm = report["confusion_matrix"].tolist()
    return {
        "accuracy": report["accuracy"],
        "roc_auc": report["roc_auc"],
        "confusion_matrix": cm,
        "feature_importances": report["feature_importances"],
        "classification_report": report["classification_report"],
    }