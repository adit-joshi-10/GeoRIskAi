import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
from src.model_features import build_model_dataset


# ─────────────────────────────────────────────
# ESCALATION LABELS
# ─────────────────────────────────────────────

# Based on UCDP intensity levels:
# 0 = No conflict
# 1 = Minor conflict  (25-999 battle deaths)
# 2 = Major conflict  (1000+ battle deaths)

ESCALATION_LABELS = {
    0: "No Conflict",
    1: "Minor",
    2: "Major",
}

ESCALATION_COLORS = {
    "No Conflict": "#1D9E75",
    "Minor":       "#EF9F27",
    "Major":       "#E24B4A",
}

FEATURES = [
    "Conflict_Last_Year",
    "Conflict_Streak",
    "Conflict_Rate_3yr",
    "Conflict_Rate_5yr",
    "Instability_Score",
]


# ─────────────────────────────────────────────
# BUILD ESCALATION DATASET
# ─────────────────────────────────────────────

def build_escalation_dataset(df):
    """
    Build dataset with escalation target:
    0 = no conflict
    1 = minor conflict
    2 = major conflict
    Uses Conflict column as proxy — if intensity column
    exists use it, otherwise split by conflict streak.
    """
    data = build_model_dataset(df)

    if "intensity_level" in data.columns:
        # Use real UCDP intensity if available
        data["Escalation"] = data["intensity_level"].fillna(0).astype(int)
        data["Escalation"] = data["Escalation"].clip(0, 2)
    else:
        # Derive escalation from conflict streak as proxy
        # 0 = no conflict
        # 1 = conflict with streak < 5 years
        # 2 = conflict with streak >= 5 years
        data["Escalation"] = 0
        data.loc[
            (data["Conflict"] == 1) & (data["Conflict_Streak"] < 5),
            "Escalation"
        ] = 1
        data.loc[
            (data["Conflict"] == 1) & (data["Conflict_Streak"] >= 5),
            "Escalation"
        ] = 2

    return data


# ─────────────────────────────────────────────
# TRAIN ESCALATION MODEL
# ─────────────────────────────────────────────

def train_escalation_model(df):
    """
    Train a multi-class Random Forest to predict escalation level.
    Returns model and evaluation report.
    """
    data = build_escalation_dataset(df).dropna(subset=FEATURES)

    X = data[FEATURES]
    y = data["Escalation"].astype(int)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=0.2,
        random_state=42,
        stratify=y,
    )

    model = RandomForestClassifier(
        n_estimators=200,
        max_depth=8,
        class_weight="balanced",
        random_state=42,
    )
    model.fit(X_train, y_train)

    y_pred = model.predict(X_test)

    report = {
        "classification_report": classification_report(
            y_test, y_pred,
            target_names=["No Conflict", "Minor", "Major"],
            output_dict=True,
        ),
        "classification_report_text": classification_report(
            y_test, y_pred,
            target_names=["No Conflict", "Minor", "Major"],
        ),
        "confusion_matrix": confusion_matrix(y_test, y_pred),
        "accuracy": round((y_pred == y_test).mean(), 4),
    }

    return model, report


# ─────────────────────────────────────────────
# PREDICT ESCALATION
# ─────────────────────────────────────────────

def predict_escalation(model, df):
    """
    Predict escalation level for each country for next year.
    Returns DataFrame with probabilities for each level.
    """
    data = build_escalation_dataset(df)
    latest_year = data["Year"].max()
    future = data[data["Year"] == latest_year].copy()
    future["Conflict_Last_Year"] = future["Conflict"]
    future = future.dropna(subset=FEATURES)

    proba = model.predict_proba(future[FEATURES])

    results = future[["Country"]].copy()
    results["No_Conflict_Prob"] = proba[:, 0].round(3)
    results["Minor_Prob"] = proba[:, 1].round(3)
    results["Major_Prob"] = proba[:, 2].round(3)

    results["Predicted_Level"] = results[
        ["No_Conflict_Prob", "Minor_Prob", "Major_Prob"]
    ].idxmax(axis=1).map({
        "No_Conflict_Prob": "No Conflict",
        "Minor_Prob":       "Minor",
        "Major_Prob":       "Major",
    })

    results = results.sort_values("Major_Prob", ascending=False)
    return results.reset_index(drop=True)