import pandas as pd


def merge_indicator(df, indicator_df, column_name):
    """
    Merge a country-year indicator dataset with the GeoRisk dataset
    """

    indicator_df = indicator_df.rename(columns={
        "Country": "Country",
        "Year": "Year",
        "Value": column_name
    })

    merged = df.merge(
        indicator_df,
        on=["Country", "Year"],
        how="left"
    )

    return merged