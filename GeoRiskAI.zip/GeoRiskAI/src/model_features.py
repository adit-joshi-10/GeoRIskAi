import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
)


# ─────────────────────────────────────────────
# FEATURE ENGINEERING
# ─────────────────────────────────────────────

def build_model_dataset(df):
    """
    Build a feature-rich dataset for the conflict prediction model.

    Features added:
        Conflict_Last_Year   – was there conflict in year t-1?
        Conflict_Streak      – how many consecutive conflict years up to t-1?
        Conflict_Rate_3yr    – share of conflict years in the past 3 years
        Conflict_Rate_5yr    – share of conflict years in the past 5 years
        Instability_Score    – country's all-time conflict frequency ratio
    """
    data = df.copy()
    data = data.sort_values(["Country", "Year"])

    # 1. Lag feature: conflict in previous year
    data["Conflict_Last_Year"] = (
        data.groupby("Country")["Conflict"].shift(1).fillna(0)
    )

    # 2. Conflict streak: consecutive conflict years ending at t-1
    data["Conflict_Streak"] = (
        data.groupby("Country")["Conflict"]
        .transform(_compute_streak)
        .shift(1)
        .fillna(0)
    )

    # 3. Rolling conflict rate over past 3 and 5 years
    data["Conflict_Rate_3yr"] = (
        data.groupby("Country")["Conflict"]
        .transform(lambda x: x.shift(1).rolling(3, min_periods=1).mean())
        .fillna(0)
    )

    data["Conflict_Rate_5yr"] = (
        data.groupby("Country")["Conflict"]
        .transform(lambda x: x.shift(1).rolling(5, min_periods=1).mean())
        .fillna(0)
    )

    # 4. All-time instability score per country
    total_years = data.groupby("Country")["Conflict"].transform("count")
    conflict_years = data.groupby("Country")["Conflict"].transform("sum")
    data["Instability_Score"] = conflict_years / total_years

    return data


def _compute_streak(series):
    """
    For each position in the series, return the length of the current
    consecutive run of 1s ending at that position (0 if not in conflict).
    """
    streak = []
    count = 0
    for val in series:
        if val == 1:
            count += 1
        else:
            count = 0
        streak.append(count)
    return pd.Series(streak, index=series.index)


# ─────────────────────────────────────────────
# MODEL TRAINING
# ─────────────────────────────────────────────

FEATURES = [
    "Conflict_Last_Year",
    "Conflict_Streak",
    "Conflict_Rate_3yr",
    "Conflict_Rate_5yr",
    "Instability_Score",
]

TARGET = "Conflict"


def train_model(df):
    """
    Train a Random Forest classifier with a proper train/test split.

    Returns:
        model       – trained RandomForestClassifier
        report      – dict with accuracy, classification report, confusion matrix, AUC
        X_test      – held-out features (for further inspection)
        y_test      – held-out labels
    """
    data = build_model_dataset(df).dropna(subset=FEATURES + [TARGET])

    X = data[FEATURES]
    y = data[TARGET].astype(int)

    # Stratified split preserves class balance in both sets
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=0.2,
        random_state=42,
        stratify=y,
    )

    model = RandomForestClassifier(
        n_estimators=200,
        max_depth=8,
        class_weight="balanced",   # handles conflict/no-conflict imbalance
        random_state=42,
    )
    model.fit(X_train, y_train)

    # ── Evaluation ──────────────────────────────
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    report = {
        "accuracy": round((y_pred == y_test).mean(), 4),
        "classification_report": classification_report(y_test, y_pred, output_dict=True),
        "classification_report_text": classification_report(y_test, y_pred),
        "confusion_matrix": confusion_matrix(y_test, y_pred),
        "roc_auc": round(roc_auc_score(y_test, y_proba), 4),
        "feature_importances": dict(zip(FEATURES, model.feature_importances_)),
    }

    return model, report, X_test, y_test


def print_evaluation(report):
    """Pretty-print the evaluation report to the console."""
    print("=" * 50)
    print("  GeoRiskAI — Model Evaluation")
    print("=" * 50)
    print(f"\n  Accuracy : {report['accuracy']:.2%}")
    print(f"  ROC-AUC  : {report['roc_auc']:.4f}")
    print("\n── Classification Report ──────────────────────")
    print(report["classification_report_text"])
    print("── Confusion Matrix ───────────────────────────")
    cm = report["confusion_matrix"]
    print(f"  True Neg : {cm[0][0]}   False Pos : {cm[0][1]}")
    print(f"  False Neg: {cm[1][0]}   True Pos  : {cm[1][1]}")
    print("\n── Feature Importances ────────────────────────")
    for feat, imp in sorted(
        report["feature_importances"].items(), key=lambda x: -x[1]
    ):
        bar = "█" * int(imp * 40)
        print(f"  {feat:<25} {bar} {imp:.3f}")
    print("=" * 50)


# ─────────────────────────────────────────────
# FUTURE PREDICTION
# ─────────────────────────────────────────────

def prepare_future_data(df):
    """
    Build the feature row for each country using the latest available year,
    so the trained model can predict conflict probability for year t+1.
    """
    data = build_model_dataset(df)
    latest_year = data["Year"].max()
    future = data[data["Year"] == latest_year].copy()

    # For future prediction, current year's conflict IS "last year"
    future["Conflict_Last_Year"] = future["Conflict"]

    return future


def predict_next_year(model, df):
    """
    Returns a DataFrame of countries with their predicted conflict
    probability for the next year, sorted high to low.
    """
    future = prepare_future_data(df)
    future = future.dropna(subset=FEATURES)

    proba = model.predict_proba(future[FEATURES])[:, 1]

    results = future[["Country"]].copy()
    results["Conflict_Probability"] = proba
    results = results.sort_values("Conflict_Probability", ascending=False)
    results["Risk_Level"] = results["Conflict_Probability"].apply(_risk_label)

    return results.reset_index(drop=True)


def _risk_label(p):
    if p >= 0.75:
        return "Critical"
    elif p >= 0.50:
        return "High"
    elif p >= 0.25:
        return "Moderate"
    else:
        return "Low"