import plotly.express as px
import pandas as pd
import plotly.io as pio

# ensure notebook renderer works
pio.renderers.default = "notebook"

def plot_risk_map(risk_scores):

    risk_df = risk_scores.reset_index()
    risk_df.columns = ["Country", "Risk"]

    fig = px.choropleth(
        risk_df,
        locations="Country",
        locationmode="country names",
        color="Risk",
        color_continuous_scale="Reds",
        title="Global GeoRisk Map"
    )

    fig.show()