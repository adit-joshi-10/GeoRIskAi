
import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from src.model_features import build_model_dataset

CLUSTER_FEATURES = [
    "Conflict_Rate_3yr",
    "Conflict_Rate_5yr",
    "Instability_Score",
    "Conflict_Streak",
]

CLUSTER_LABELS = {
    0: "Stable",
    1: "Fragile",
    2: "Conflict-Prone",
    3: "Chronically Unstable",
}

CLUSTER_COLORS = {
    "Stable": "#1D9E75",
    "Fragile": "#378ADD",
    "Conflict-Prone": "#EF9F27",
    "Chronically Unstable": "#E24B4A",
}


def build_cluster_dataset(df):
    data = build_model_dataset(df)
    available = [f for f in CLUSTER_FEATURES if f in data.columns]
    agg = data.groupby("Country")[available].mean()
    return agg


def run_clustering(df, n_clusters=4, random_state=42):
    agg = build_cluster_dataset(df)

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(agg)

    kmeans = KMeans(
        n_clusters=n_clusters,
        random_state=random_state,
        n_init=10,
    )
    clusters = kmeans.fit_predict(X_scaled)

    result_df = agg.copy()
    result_df["Cluster"] = clusters

    mean_instability = result_df.groupby("Cluster")["Instability_Score"].mean()
    ranked = mean_instability.rank(method="first").astype(int) - 1
    cluster_instability = ranked.to_dict()

    result_df["Cluster_Label"] = result_df["Cluster"].map(
        lambda c: CLUSTER_LABELS[cluster_instability[c]]
    )

    pca = PCA(n_components=2, random_state=random_state)
    coords = pca.fit_transform(X_scaled)

    pca_df = pd.DataFrame()
    pca_df["Country"] = agg.index
    pca_df["PCA_1"] = coords[:, 0]
    pca_df["PCA_2"] = coords[:, 1]
    pca_df["Cluster_Label"] = result_df["Cluster_Label"].values
    pca_df["Instability"] = agg["Instability_Score"].values

    return result_df.reset_index(), kmeans, scaler, pca_df


def cluster_summary(result_df):
    available = [f for f in CLUSTER_FEATURES if f in result_df.columns]
    summary = result_df.groupby("Cluster_Label")[available].mean().round(3)
    summary["Country_Count"] = result_df.groupby("Cluster_Label").size()
    return summary