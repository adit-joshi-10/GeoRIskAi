import pandas as pd


def country_risk_score(df):

    # total years observed
    total_years = df.groupby("Country").size()

    # conflict years
    conflict_years = df[df["Conflict"] == 1].groupby("Country").size()

    conflict_years = conflict_years.fillna(0)

    # instability ratio
    instability = conflict_years / total_years

    risk_score = instability.sort_values(ascending=False)

    return risk_score