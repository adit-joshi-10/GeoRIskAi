import pandas as pd
import requests
import feedparser
from datetime import datetime, timedelta


# ─────────────────────────────────────────────
# CONFIGURATION
# ─────────────────────────────────────────────

GDELT_DOC_URL = "https://api.gdeltproject.org/api/v2/doc/doc"

# RSS feeds — no limits, always work
RSS_FEEDS = {
    "default": [
        "http://feeds.bbci.co.uk/news/world/rss.xml",
        "https://feeds.reuters.com/reuters/worldNews",
        "https://www.aljazeera.com/xml/rss/all.xml",
        "https://rss.dw.com/rdf/rss-en-world",
    ]
}

CONFLICT_KEYWORDS = [
    "war", "conflict", "attack", "military", "bomb", "strike",
    "killed", "troops", "missile", "explosion", "rebel", "coup",
    "protest", "violence", "gunfire", "airstrike", "siege",
    "ceasefire", "casualties", "terror", "insurgent", "invasion",
    "offensive", "battle", "clashes", "unrest", "massacre",
    "hostage", "drone", "sanction", "artillery", "shelling",
    "shooting", "forces", "army", "fighters", "wounded", "dead",
    "security", "threat", "crisis", "emergency", "tension",
]


def is_conflict_related(title):
    if not title:
        return False
    return any(k in title.lower() for k in CONFLICT_KEYWORDS)


# ─────────────────────────────────────────────
# METHOD 1 — GDELT
# ─────────────────────────────────────────────

def fetch_via_gdelt(country, max_records=8):
    try:
        params = {
            "query":      f"{country} conflict OR war OR military OR attack",
            "mode":       "artlist",
            "maxrecords": 100,
            "format":     "json",
            "timespan":   "7d",
        }
        response = requests.get(
            GDELT_DOC_URL, params=params,
            timeout=15, headers={"User-Agent": "GeoRiskAI/1.0"},
        )
        if response.status_code != 200:
            return []

        data = response.json()
        all_articles = data.get("articles", [])
        if not all_articles:
            return []

        articles = []
        for a in all_articles:
            title = a.get("title", "") or ""
            if not title:
                continue
            articles.append({
                "title":   title,
                "url":     a.get("url", ""),
                "date":    a.get("seendate", "")[:8],
                "source":  a.get("domain", ""),
                "country": country,
            })
            if len(articles) >= max_records:
                break

        return articles

    except Exception as e:
        print(f"GDELT failed for {country}: {e}")
        return []


# ─────────────────────────────────────────────
# METHOD 2 — RSS FEEDS
# ─────────────────────────────────────────────

def fetch_via_rss(country, max_records=8):
    try:
        articles = []

        for feed_url in RSS_FEEDS["default"]:
            feed = feedparser.parse(feed_url)

            for entry in feed.entries:
                title   = entry.get("title", "") or ""
                summary = entry.get("summary", "") or ""
                combined = (title + " " + summary).lower()

                # Must mention the country AND be conflict related
                if country.lower() in combined and is_conflict_related(title):
                    articles.append({
                        "title":   title,
                        "url":     entry.get("link", ""),
                        "date":    entry.get("published", "")[:10],
                        "source":  feed.feed.get("title", feed_url),
                        "country": country,
                    })

                if len(articles) >= max_records:
                    break

            if len(articles) >= max_records:
                break

        return articles

    except Exception as e:
        print(f"RSS failed for {country}: {e}")
        return []


# ─────────────────────────────────────────────
# MAIN — HYBRID FETCH
# ─────────────────────────────────────────────

def get_live_news(country, max_records=8):
    """
    Try GDELT first. If it returns nothing, fall back to RSS feeds.
    """
    # Try GDELT
    articles = fetch_via_gdelt(country, max_records)
    if articles:
        return articles

    # Fall back to RSS
    print(f"GDELT empty for {country}, trying RSS...")
    articles = fetch_via_rss(country, max_records)
    if articles:
        return articles

    # Last resort — return any RSS articles mentioning the country
    try:
        fallback = []
        for feed_url in RSS_FEEDS["default"]:
            feed = feedparser.parse(feed_url)
            for entry in feed.entries:
                title = entry.get("title", "") or ""
                if country.lower() in (title + entry.get("summary", "")).lower():
                    fallback.append({
                        "title":   title,
                        "url":     entry.get("link", ""),
                        "date":    entry.get("published", "")[:10],
                        "source":  feed.feed.get("title", ""),
                        "country": country,
                    })
                if len(fallback) >= max_records:
                    break
            if len(fallback) >= max_records:
                break
        return fallback
    except Exception:
        return []


# ─────────────────────────────────────────────
# CONFLICT SIGNALS FOR MULTIPLE COUNTRIES
# ─────────────────────────────────────────────

def fetch_conflict_signals(countries):
    results = []

    for country in countries:
        articles = get_live_news(country, max_records=20)
        conflict_count = sum(
            1 for a in articles
            if is_conflict_related(a.get("title", "") or "")
        )
        if conflict_count == 0:
            conflict_count = len(articles)

        results.append({
            "Country":         country,
            "News_Risk_Score": conflict_count,
        })

    df = pd.DataFrame(results)
    max_score = df["News_Risk_Score"].max()
    if max_score > 0:
        df["News_Risk_Score"] = (df["News_Risk_Score"] / max_score).round(3)

    return df


def compute_news_risk_score(signals_df):
    return signals_df