import pandas as pd


def conflicts_by_country(df):
    """
    Count number of conflict years per country
    """
    result = df[df["Conflict"] == 1]["Country"].value_counts()
    return result


def conflicts_by_year(df):
    """
    Count conflicts per year globally
    """
    result = df[df["Conflict"] == 1].groupby("Year").size()
    return result


def conflict_frequency_index(df):
    """
    Calculate instability score based on number of conflict years
    """
    conflicts = df[df["Conflict"] == 1]

    score = conflicts.groupby("Country").size()

    score = score.sort_values(ascending=False)

    return score
def country_instability_score(df):
    """
    Calculate instability score based on proportion of conflict years
    """

    total_years = df.groupby("Country").size()

    conflict_years = df[df["Conflict"] == 1].groupby("Country").size()

    score = (conflict_years / total_years).fillna(0)

    score = score.sort_values(ascending=False)

    return score