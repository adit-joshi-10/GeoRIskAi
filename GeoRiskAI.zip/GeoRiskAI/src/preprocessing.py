import pandas as pd


def clean_conflict_data(conflicts):
    """
    Extract and clean conflict events dataset
    """

    conflict_events = conflicts[["location", "year"]]

    conflict_events = conflict_events.rename(columns={
        "location": "Country",
        "year": "Year"
    })

    conflict_events = conflict_events.drop_duplicates()

    return conflict_events


def mark_conflicts(df, conflict_events):
    """
    Mark conflict years in the GeoRisk dataset
    """

    df["Conflict"] = df.apply(
        lambda row: 1 if (
            (conflict_events["Country"] == row["Country"]) &
            (conflict_events["Year"] == row["Year"])
        ).any() else 0,
        axis=1
    )

    return df