import pandas as pd


def conflict_growth_rate(df):
    """
    Calculate yearly change in global conflicts
    """

    conflict_per_year = df[df["Conflict"] == 1].groupby("Year").size()

    growth = conflict_per_year.pct_change()

    return growth


def country_conflict_trend(df):
    """
    Measure whether conflicts are increasing or decreasing in each country
    """

    country_year = df[df["Conflict"] == 1].groupby(["Country", "Year"]).size()

    trend = country_year.groupby("Country").pct_change()

    return trend