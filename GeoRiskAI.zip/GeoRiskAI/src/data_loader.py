import pandas as pd

def load_conflict_data():

    path = "data/raw/conflict_data.csv"

    conflicts = pd.read_csv(path)

    return conflicts


def load_georisk_dataset():

    path = "data/processed/georisk_dataset_v2.csv"

    df = pd.read_csv(path)

    return df
def prepare_prediction_data(df):

    data = df.copy()

    # previous year conflict
    data["Conflict_Last_Year"] = data.groupby("Country")["Conflict"].shift(1)

    data["Conflict_Last_Year"] = data["Conflict_Last_Year"].fillna(0)

    return data