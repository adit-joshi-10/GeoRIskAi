import wbgapi as wb
import pandas as pd
import os


# ─────────────────────────────────────────────
# WORLD BANK INDICATOR CODES
# ─────────────────────────────────────────────

INDICATORS = {
    "GDP_Growth":           "NY.GDP.MKTP.KD.ZG",
    "Political_Stability":  "PV.EST",
    "Military_Spending":    "MS.MIL.XPND.GD.ZS",
    "Inflation":            "FP.CPI.TOTL.ZG",
    "Unemployment":         "SL.UEM.TOTL.ZS",
    "Population":           "SP.POP.TOTL",
}

SAVE_PATH = "data/raw/world_bank_live.csv"


# ─────────────────────────────────────────────
# FETCH
# ─────────────────────────────────────────────

def fetch_world_bank_data(start_year=2000, end_year=2024):
    """
    Fetch all indicators from World Bank API for all countries.
    Returns a merged country-year DataFrame.
    """
    all_frames = []

    for col_name, indicator_code in INDICATORS.items():
        print(f"  Fetching {col_name} ({indicator_code})...")

        try:
            raw = wb.data.DataFrame(
                indicator_code,
                time=range(start_year, end_year + 1),
                labels=True,
            )

            # wb returns countries as index, years as columns
            raw = raw.reset_index()

            # Drop the economy code column if present
            if "economy" in raw.columns:
                raw = raw.drop(columns=["economy"])

            # Rename country label column
            raw = raw.rename(columns={"Country": "Country"})

            # Melt from wide to long format
            id_col = raw.columns[0]
            raw = raw.rename(columns={id_col: "Country"})
            melted = raw.melt(
                id_vars="Country",
                var_name="Year",
                value_name=col_name,
            )

            # Clean year column — World Bank prefixes with YR
            melted["Year"] = (
                melted["Year"]
                .astype(str)
                .str.replace("YR", "", regex=False)
                .astype(int)
            )

            all_frames.append(melted)

        except Exception as e:
            print(f"  Warning: could not fetch {col_name} — {e}")
            continue

    if not all_frames:
        print("No data fetched.")
        return pd.DataFrame()

    # Merge all indicators on Country + Year
    merged = all_frames[0]
    for frame in all_frames[1:]:
        merged = merged.merge(frame, on=["Country", "Year"], how="outer")

    merged = merged.sort_values(["Country", "Year"]).reset_index(drop=True)

    print(f"  Done. Shape: {merged.shape}")
    return merged


# ─────────────────────────────────────────────
# SAVE
# ─────────────────────────────────────────────

def save_world_bank_data(df):
    """Save fetched data to data/raw/world_bank_live.csv"""
    os.makedirs("data/raw", exist_ok=True)
    df.to_csv(SAVE_PATH, index=False)
    print(f"  Saved to {SAVE_PATH}")


# ─────────────────────────────────────────────
# LOAD
# ─────────────────────────────────────────────

def load_world_bank_data():
    """Load previously saved World Bank data."""
    if not os.path.exists(SAVE_PATH):
        print("No cached World Bank data found. Fetching now...")
        df = fetch_world_bank_data()
        save_world_bank_data(df)
        return df

    df = pd.read_csv(SAVE_PATH)
    print(f"  Loaded World Bank data from cache. Shape: {df.shape}")
    return df


# ─────────────────────────────────────────────
# MERGE INTO MASTER DATASET
# ─────────────────────────────────────────────

def merge_into_dataset(base_df):
    """
    Merge live World Bank data into the GeoRisk master dataset.
    Overwrites existing World Bank columns with fresh data.
    """
    wb_df = load_world_bank_data()

    if wb_df.empty:
        print("  Warning: World Bank data empty, skipping merge.")
        return base_df

    # Drop old World Bank columns from base if they exist
    old_cols = list(INDICATORS.keys())
    base_df = base_df.drop(
        columns=[c for c in old_cols if c in base_df.columns],
        errors="ignore",
    )

    merged = base_df.merge(wb_df, on=["Country", "Year"], how="left")
    print(f"  Merged. Final shape: {merged.shape}")
    return merged


# ─────────────────────────────────────────────
# QUICK TEST
# ─────────────────────────────────────────────

if __name__ == "__main__":
    print("Fetching World Bank data...")
    df = fetch_world_bank_data(start_year=2000, end_year=2024)
    print(df.head(10).to_string())
    save_world_bank_data(df)