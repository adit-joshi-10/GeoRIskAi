from src.data_loader import load_conflict_data, load_georisk_dataset
from src.preprocessing import clean_conflict_data, mark_conflicts
from src.world_bank_fetcher import merge_into_dataset


def build_master_dataset(use_live_data=False):

    # Load datasets
    conflicts = load_conflict_data()
    df = load_georisk_dataset()

    # Clean conflict dataset
    conflict_events = clean_conflict_data(conflicts)

    # Mark conflicts
    df = mark_conflicts(df, conflict_events)

    # Optionally merge live World Bank data
    if use_live_data:
        print("Merging live World Bank data...")
        df = merge_into_dataset(df)

    return df