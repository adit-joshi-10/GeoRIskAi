import pandas as pd
import requests
from src.news_fetcher import is_conflict_related, GDELT_DOC_URL


# ─────────────────────────────────────────────
# TOP 50 COUNTRIES TO SCAN
# ─────────────────────────────────────────────

TOP_50_COUNTRIES = [
    "Afghanistan", "India", "Colombia", "Iraq", "Ethiopia",
    "Israel", "Sudan", "Pakistan", "Mali", "Somalia",
    "Syria", "Yemen", "Nigeria", "Myanmar", "Ukraine",
    "Congo", "Libya", "Central African Republic", "Mozambique",
    "Cameroon", "Egypt", "Iran", "Turkey", "Philippines",
    "Bangladesh", "Indonesia", "Thailand", "Venezuela",
    "Mexico", "Haiti", "Kenya", "Uganda", "Rwanda",
    "Burundi", "Chad", "Niger", "Burkina Faso", "Guinea",
    "Zimbabwe", "Angola", "Algeria", "Morocco", "Lebanon",
    "Jordan", "Azerbaijan", "Georgia", "Armenia", "Serbia",
    "Kosovo", "Bosnia",
]

COUNTRY_ALIASES = {
    "Congo":                    ["congo", "drc", "democratic republic"],
    "Central African Republic": ["central african", "car "],
    "Burkina Faso":             ["burkina"],
    "Bosnia":                   ["bosnia", "herzegovina"],
    "Kosovo":                   ["kosovo"],
    "Myanmar":                  ["myanmar", "burma"],
    "Iran":                     ["iran", "iranian"],
    "Syria":                    ["syria", "syrian"],
    "Yemen":                    ["yemen", "yemeni"],
    "Libya":                    ["libya", "libyan"],
    "Ukraine":                  ["ukraine", "ukrainian"],
    "Israel":                   ["israel", "israeli", "gaza", "west bank"],
    "Sudan":                    ["sudan", "sudanese", "khartoum"],
    "Ethiopia":                 ["ethiopia", "ethiopian", "tigray"],
    "Somalia":                  ["somalia", "somali", "mogadishu"],
    "Mali":                     ["mali", "malian", "bamako"],
    "Niger":                    ["niger ", "nigerien"],
    "Chad":                     ["chad", "chadian"],
    "Nigeria":                  ["nigeria", "nigerian"],
    "Haiti":                    ["haiti", "haitian"],
    "Venezuela":                ["venezuela", "venezuelan"],
    "Mexico":                   ["mexico", "mexican", "cartel"],
}


# ─────────────────────────────────────────────
# FETCH NEWS SCORES — ONE BULK REQUEST
# ─────────────────────────────────────────────

def fetch_all_news_scores():
    """
    Fetch all conflict news in ONE GDELT request.
    Then count country mentions across all articles.
    Fast — one request instead of 50.
    """
    try:
        params = {
            "query":      "conflict OR war OR military OR attack OR killed OR troops OR bombing",
            "mode":       "artlist",
            "maxrecords": 250,
            "format":     "json",
            "timespan":   "3d",
        }

        response = requests.get(
            GDELT_DOC_URL,
            params=params,
            timeout=20,
            headers={"User-Agent": "GeoRiskAI/1.0"},
        )

        all_articles = []
        if response.status_code == 200:
            data = response.json()
            all_articles = data.get("articles", [])
            print(f"GDELT returned {len(all_articles)} articles")
        else:
            print(f"GDELT status: {response.status_code}")

    except Exception as e:
        print(f"GDELT bulk fetch failed: {e}")
        all_articles = []

    # Build full text for each article
    article_texts = []
    for a in all_articles:
        title  = (a.get("title", "") or "").lower()
        url    = (a.get("url", "") or "").lower()
        source = (a.get("domain", "") or "").lower()
        article_texts.append(f"{title} {url} {source}")

    # Count mentions per country
    results = []
    for country in TOP_50_COUNTRIES:
        country_lower = country.lower()

        search_terms = [country_lower]
        if country in COUNTRY_ALIASES:
            search_terms.extend(COUNTRY_ALIASES[country])

        count = sum(
            1 for text in article_texts
            if any(term in text for term in search_terms)
        )

        results.append({
            "Country":        country,
            "Raw_News_Count": count,
        })

    df = pd.DataFrame(results)

    # If everything is 0 use RSS fallback
    if df["Raw_News_Count"].sum() == 0:
        print("GDELT returned no matches, using RSS fallback...")
        from src.news_fetcher import fetch_via_rss
        for country in TOP_50_COUNTRIES:
            articles = fetch_via_rss(country, max_records=10)
            df.loc[df["Country"] == country, "Raw_News_Count"] = len(articles)

    max_score = df["Raw_News_Count"].max()
    if max_score > 0:
        df["News_Risk_Score"] = (df["Raw_News_Count"] / max_score).round(3)
    else:
        df["News_Risk_Score"] = 0

    return df


# ─────────────────────────────────────────────
# COMPUTE GEORISK LIVE SCORE
# ─────────────────────────────────────────────

def compute_live_score(predictions_df, news_df, ml_weight=0.6, news_weight=0.4):
    merged = predictions_df.merge(
        news_df[["Country", "News_Risk_Score", "Raw_News_Count"]],
        on="Country",
        how="left",
    )
    merged["News_Risk_Score"] = merged["News_Risk_Score"].fillna(0)
    merged["Raw_News_Count"]  = merged["Raw_News_Count"].fillna(0)
    merged["GeoRisk_Live_Score"] = (
        merged["Conflict_Probability"] * ml_weight +
        merged["News_Risk_Score"] * news_weight
    ).round(3)
    merged = merged.sort_values(
        "GeoRisk_Live_Score", ascending=False
    ).reset_index(drop=True)
    return merged


# ─────────────────────────────────────────────
# ANOMALY DETECTION
# ─────────────────────────────────────────────

def detect_anomalies(live_score_df, news_threshold=0.1, ml_threshold=0.6):
    anomalies = live_score_df[
        (live_score_df["News_Risk_Score"] >= news_threshold) &
        (live_score_df["Conflict_Probability"] < ml_threshold)
    ].copy()
    anomalies["Anomaly_Gap"] = (
        anomalies["News_Risk_Score"] - anomalies["Conflict_Probability"]
    ).round(3)
    anomalies = anomalies.sort_values(
        "Anomaly_Gap", ascending=False
    ).reset_index(drop=True)
    return anomalies


# ─────────────────────────────────────────────
# LIVE ALERT LABEL
# ─────────────────────────────────────────────

def get_alert_level(news_score, ml_prob):
    if news_score >= 0.7 and ml_prob < 0.4:
        return "🚨 Emerging Threat"
    elif news_score >= 0.5 and ml_prob < 0.5:
        return "⚠️ Watch"
    elif news_score >= 0.3 and ml_prob >= 0.7:
        return "🔥 Confirmed High Risk"
    elif news_score >= 0.3 and ml_prob >= 0.4:
        return "📌 Elevated"
    else:
        return "✅ Normal"