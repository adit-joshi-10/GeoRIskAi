import matplotlib.pyplot as plt
import seaborn as sns


def plot_global_conflicts(conflict_year):
    """
    Plot global conflicts per year
    """

    plt.figure(figsize=(10,5))

    conflict_year.plot()

    plt.title("Global Conflicts Over Time")
    plt.xlabel("Year")
    plt.ylabel("Number of Conflicts")

    plt.show()


def plot_top_conflict_countries(risk_score):
    """
    Plot top countries with the most conflict years
    """

    plt.figure(figsize=(10,5))

    risk_score.head(10).plot(kind="bar")

    plt.title("Top 10 Conflict-Prone Countries")
    plt.xlabel("Country")
    plt.ylabel("Conflict Years")

    plt.xticks(rotation=45)

    plt.show()


def plot_conflict_growth(growth):
    """
    Plot yearly growth rate of conflicts
    """

    plt.figure(figsize=(10,5))

    growth.plot()

    plt.title("Global Conflict Growth Rate")
    plt.xlabel("Year")
    plt.ylabel("Growth Rate")

    plt.show()


def plot_conflict_heatmap(df):
    """
    Create heatmap of conflicts by country and year
    """

    conflict_data = df[df["Conflict"] == 1]

    pivot = conflict_data.pivot_table(
        index="Country",
        columns="Year",
        values="Conflict",
        aggfunc="sum",
        fill_value=0
    )

    plt.figure(figsize=(12,10))

    sns.heatmap(
        pivot,
        cmap="Reds",
        cbar=True
    )

    plt.title("Global Conflict Heatmap")

    plt.xlabel("Year")
    plt.ylabel("Country")

    plt.show()